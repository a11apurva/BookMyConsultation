package com.example.doctorservice.services;

import com.example.doctorservice.dto.doctorInfoDTO;

public interface auxiliaryService {

    public Boolean validateInput(doctorInfoDTO info);

}
