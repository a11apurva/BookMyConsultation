package com.upgrad.doctorservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoctorServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
